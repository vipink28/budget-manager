import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../auth/authSlice';
import incomeReducer from '../features/incomeSlice';
import expenseReducer from '../features/expenseSlice';
import budgetReducer from '../features/budgetSlice';
import savingsReducer from '../features/savingsGloals';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    income: incomeReducer,
    expense: expenseReducer,
    budget: budgetReducer,
    savings: savingsReducer
  }
});
