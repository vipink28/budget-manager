export const loadUserData = () => {
    const token = localStorage.getItem('token');
    if (token) {
        return { token, status: 'succeeded', error: null };
    } else {
        return undefined;
    }
};

export const formatDate = (dateString) => {
    let date = new Date(dateString);
    return `
    ${date.getDate()}
    ${date.toLocaleDateString("en-US", { month: 'short' })} 
    ${date.getFullYear()} 
    ${date.toLocaleString("en-US", { hour: 'numeric', minute: 'numeric', hour12: true })}`
}