import React, { useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import Home from './pages/Home';
import Register from './auth/Register';
import Login from './auth/Login';
import { useDispatch, useSelector } from 'react-redux';
import { getUser } from './auth/authSlice';
import ProtectedRoute from './auth/ProtectedRoute';
import Dashboard from './pages/Dashboard';
import BudgetPlan from './pages/BudgetPlan';
import ExpenseTracker from './pages/ExpenseTracker';
import FinancialInsights from './pages/FinancialInsights';
import FinancialReport from './pages/FinancialReport';
import IncomeTracker from './pages/IncomeTracker';
import Notifications from './pages/Notifications';
import SavingsGoal from './pages/SavingsGoal';
import UserProfile from './pages/UserProfile';
import PageNotFound from './pages/PageNotFound';
import AdminLayout from './pages/Layout/AdminLayout';



function App() {
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);

  useEffect(() => {
    const userId = localStorage.getItem('userId');
    if (userId) {
      dispatch(getUser());
    }
  }, [dispatch]);


  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Navigate to='/login' />}></Route>
        <Route path='/' element={<Home />}>
          <Route path='/register' element={<Register />}></Route>
          <Route path='/login' element={<Login />}></Route>
        </Route>
        <Route path='/admin' element={<Navigate to='/admin/dashboard' />}></Route>
        <Route path='/admin' element={<AdminLayout />}>
          <Route path="dashboard" index element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="budget-plan" element={<ProtectedRoute><BudgetPlan /></ProtectedRoute>} />
          <Route path="expense" element={<ProtectedRoute><ExpenseTracker /></ProtectedRoute>} />
          <Route path="financial-insights" element={<ProtectedRoute><FinancialInsights /></ProtectedRoute>} />
          <Route path="financial-reports" element={<ProtectedRoute><FinancialReport /></ProtectedRoute>} />
          <Route path="income" element={<ProtectedRoute><IncomeTracker /></ProtectedRoute>} />
          <Route path="notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
          <Route path="savings-goal" element={<ProtectedRoute><SavingsGoal /></ProtectedRoute>} />
          <Route path="profile" element={<ProtectedRoute><UserProfile /></ProtectedRoute>} />
          <Route path="*" element={<PageNotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
