import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { registerUser } from './authSlice';

function Register(props) {
    const dispatch = useDispatch();
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: ''
    });
    const [message, setMessage] = useState('');

    const inputField = useRef(null);

    const [errors, setErrors] = useState({
        email: [],
        name: [],
        password: []
    });

    const [dirty, setDirty] = useState({
        email: false,
        name: false,
        password: false
    });

    const validate = () => {
        let errorsData = {};
        errorsData.email = [];
        errorsData.password = [];
        errorsData.name = [];

        //email
        if (!formData.email) {
            errorsData.email.push("Please provide email");
        }
        let emailreg = /^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/;
        if (formData.email) {
            if (!emailreg.test(formData.email)) {
                errorsData.email.push("Please enter valid email");
            }
        }

        //username
        if (!formData.name) {
            errorsData.name.push("Please provide username");
        }

        //password
        if (!formData.password) {
            errorsData.password.push("Please provide password");
        }
        setErrors(errorsData);
    }

    useEffect(validate, [formData]);

    const isValid = () => {
        let valid = true;
        for (let control in errors) {
            if (errors[control].length > 0) {
                valid = false;
            }
        }
        return valid;
    }

    const onblurHandle = (e) => {
        const { name } = e.target;
        setDirty((dirty) => ({
            ...dirty,
            [name]: true
        }))
        validate();
    }



    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
            active: true
        }))
    }

    const submitForm = (e) => {
        e.preventDefault();
        if (isValid()) {
            dispatch(registerUser(formData));
        } else {
            const currValue = inputField.current.value;
            if (!currValue) {
                Object.keys(dirty).forEach((abc) => dirty[abc] = true)
            }
            setMessage("Please resolve errors in the form");
        }

    }
    return (
        <div className='py-2'>
            <h4 className='mb-4'>Register</h4>

            <form>
                <div className='mb-3'>
                    <label className='form-label'>Username</label>
                    <input ref={inputField} type="text" name='username' className='form-control' onChange={handleChange} onBlur={onblurHandle} />
                    <div className='text-danger'>{dirty["username"] && errors["username"][0] ? errors["username"] : ""}</div>
                </div>
                <div className='mb-3'>
                    <label className='form-label'>Email</label>
                    <input ref={inputField} type="email" name='email' className='form-control' onChange={handleChange} onBlur={onblurHandle} />
                    <div className='text-danger'>{dirty["email"] && errors["email"][0] ? errors["email"] : ""}</div>
                </div>
                <div className='mb-3'>
                    <label className='form-label'>Password</label>
                    <input ref={inputField} type="password" name='password' className='form-control' onChange={handleChange} onBlur={onblurHandle} />
                    <div className='text-danger'>{dirty["password"] && errors["password"][0] ? errors["password"] : ""}</div>
                </div>
                {message}
                <button className='btn btn-primary mt-3' onClick={submitForm}>Register</button>
                <p className='mt-3 mb-0'>Already have an account? <Link to='/login'>Login</Link></p>
            </form>
        </div>
    );
}

export default Register;