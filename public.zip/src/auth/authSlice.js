import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from '../helper/axios';
export const initialState = {
    user: null, loading: false, error: null, token: localStorage.getItem('token') || null,
};

export const registerUser = createAsyncThunk(
    'auth/register',
    async (userData, { rejectWithValue }) => {
        try {
            const response = await axios.post('/users/register', userData);
            localStorage.setItem('token', response.data.token);
            localStorage.setItem('userId', response.data.user.id);
            return response.data;
        } catch (error) {
            return rejectWithValue(error.response.data);
        }
    }
);

export const loginUser = createAsyncThunk(
    'auth/login',
    async (userData, { rejectWithValue }) => {
        try {
            const response = await axios.post('/users/login', userData);
            // Save token to local storage or handle it as needed
            localStorage.setItem('token', response.data.token);
            localStorage.setItem('userId', response.data.user.id);
            return response.data.user; // Assuming the API returns user data
        } catch (error) {
            return rejectWithValue(error.response.data);
        }
    }
);

export const getUser = createAsyncThunk(
    'auth/getUser',
    async (_, { rejectWithValue }) => {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('No user ID found');
            }
            const response = await axios.get(`/users/${userId}`);
            return response.data;
        } catch (error) {
            return rejectWithValue(error.response ? error.response.data : error.message);
        }
    }
);


const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            // registerUser cases
            .addCase(registerUser.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(registerUser.fulfilled, (state, action) => {
                state.loading = false;
                state.user = action.payload;
                state.token = localStorage.getItem('token'); // Assuming the token is saved in localStorage
            })
            .addCase(registerUser.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })
            // loginUser cases
            .addCase(loginUser.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(loginUser.fulfilled, (state, action) => {
                state.loading = false;
                state.user = action.payload;
                state.token = localStorage.getItem('token');
            })
            .addCase(loginUser.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })
            // getUser cases
            .addCase(getUser.pending, (state) => {
                state.loading = true;
            })
            .addCase(getUser.fulfilled, (state, action) => {
                state.loading = false;
                state.user = action.payload;
            })
            .addCase(getUser.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
                state.token = null; // Clear token if fetching user fails
            });
    },
});

export default authSlice.reducer;