import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { loginUser } from './authSlice';

function Login(props) {

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { user } = useSelector((state) => state.auth);
    const [formData, setFormData] = useState({
        email: '',
        password: ''
    });

    const [message, setMessage] = useState('');

    const inputField = useRef(null);

    const [errors, setErrors] = useState({
        email: [],
        password: []
    });

    const [dirty, setDirty] = useState({
        email: false,
        password: false
    });

    const validate = () => {
        let errorsData = {};
        errorsData.email = [];
        errorsData.password = [];

        //email
        if (!formData.email) {
            errorsData.email.push("Please provide email");
        }
        let emailreg = /^([a-zA-Z0-9_\-.]+)@([a-zA-Z0-9_\-.]+)\.([a-zA-Z]{2,5})$/;
        if (formData.email) {
            if (!emailreg.test(formData.email)) {
                errorsData.email.push("Please enter valid email");
            }
        }

        //password
        if (!formData.password) {
            errorsData.password.push("Please provide password");
        }
        setErrors(errorsData);
    }

    useEffect(validate, [formData]);

    const isValid = () => {
        let valid = true;
        for (let control in errors) {
            if (errors[control].length > 0) {
                valid = false;
            }
        }
        return valid;
    }

    const onblurHandle = (e) => {
        const { name } = e.target;
        setDirty((dirty) => ({
            ...dirty,
            [name]: true
        }))
        validate();
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value
        }))
    }

    const submitForm = (e) => {
        e.preventDefault();

        if (isValid()) {
            dispatch(loginUser(formData))
        } else {
            const currValue = inputField.current.value;
            if (!currValue) {
                Object.keys(dirty).forEach((abc) => dirty[abc] = true)
            }
            setMessage("Please resolve errors in the form");
        }
    }
    useEffect(() => {
        if (user) {
            navigate('/admin')
        }
    }, [user])

    return (
        <div className='py-2'>
            <h4 className='mb-4'>Login</h4>

            <form>
                <div className='mb-3'>
                    <label className='form-label'>Email</label>
                    <input ref={inputField} type="email" name='email' className='form-control' onChange={handleChange} onBlur={onblurHandle} />
                    <div className='text-danger'>{dirty["email"] && errors["email"][0] ? errors["email"] : ""}</div>
                </div>
                <div className='mb-3'>
                    <label className='form-label'>Password</label>
                    <input ref={inputField} type="password" name='password' className='form-control' onChange={handleChange} onBlur={onblurHandle} />
                    <div className='text-danger'>{dirty["password"] && errors["password"][0] ? errors["password"] : ""}</div>
                </div>
                {message}
                <button className='btn btn-primary mt-3' onClick={submitForm}>Login</button>
                <p className='mt-3 mb-0'>Don't have an account? <Link to='/register'>Register</Link></p>
            </form>
        </div>
    );
}

export default Login;