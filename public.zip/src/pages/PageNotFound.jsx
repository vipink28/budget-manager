import React from 'react';

function PageNotFound(props) {
    return (
        <div className='container d-flex flex-column justify-content-center align-items-center'>
            <h1>Error 404</h1>
            <h3>Page not found</h3>
        </div>
    );
}

export default PageNotFound;