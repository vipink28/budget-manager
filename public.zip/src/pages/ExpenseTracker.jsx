import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Alert from '../components/Alert';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrash } from '@fortawesome/free-solid-svg-icons';
import { addExpense, deleteExpense, fetchExpenses, resetAddExpenseSuccess, updateExpense } from '../features/expenseSlice';
import { formatDate } from '../helper';

function ExpenseTracker(props) {
    const dispatch = useDispatch();
    const { addExpenseSuccess, expenses } = useSelector(state => state.expense);
    const { user } = useSelector(state => state.auth);
    const [alertBox, setAlertBox] = useState({
        show: false,
        alertType: 'success',
        alertMessage: ''
    });
    const [expense, setExpense] = useState({ description: '', amount: 0, date: '', category: '' });
    const [editingExpense, setEditingExpense] = useState(null);

    const handleEdit = (expense) => {
        setEditingExpense(expense._id);
        setExpense({
            description: expense.description,
            amount: expense.amount,
            category: expense.category,
            date: expense.date
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (editingExpense) {
            dispatch(updateExpense({ id: editingExpense, data: expense }));
            setEditingExpense(null);
        } else {
            dispatch(addExpense(expense));
        }
        setExpense({ description: '', amount: 0, date: '', category: '' });
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setExpense((prev) => ({
            ...prev,
            [name]: value,
            user: user
        }))
    }

    const handleDelete = (id) => {
        dispatch(deleteExpense(id));
    };

    useEffect(() => {
        if (addExpenseSuccess) {
            setAlertBox({ alertType: 'success', alertMessage: 'Expense Added Successfully', show: true });
            dispatch(fetchExpenses(user._id));
            dispatch(resetAddExpenseSuccess());
        }
    }, [addExpenseSuccess, dispatch]);

    useEffect(() => {
        if (user) {
            debugger
            dispatch(fetchExpenses(user._id))
        }
    }, [user, dispatch])

    return (
        <div className="container mt-4">
            <h2>Expense Tracker</h2>
            <form onSubmit={handleSubmit} className="mb-3">
                <div className="mb-3">
                    <label className='form-label'>Expense Description</label>
                    <input type="text" className="form-control" name='description' value={expense.description} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label className='form-label'>Amount</label>
                    <input type="number" className="form-control" name='amount' value={expense.amount} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label className='form-label'>Category</label>
                    <select
                        className="form-control"
                        value={expense.category}
                        onChange={handleChange}
                        name='category'
                    >
                        <option value="">Select a Category</option>
                        <option value="Grocery">Grocery</option>
                        <option value="Bills">Bills</option>
                        <option value="Travel">Travel</option>
                    </select>
                </div>
                <div className='mb-3'>
                    <label className='form-label'>Date</label>
                    <input type="date" name="date" className='form-control' value={expense.date} onChange={handleChange} />
                </div>
                <button type="submit" className="btn btn-primary">{editingExpense ? 'Update Expense' : 'Add Expense'}</button>
            </form>
            <table className="table">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {expenses.map((exp, index) => (
                        <tr key={index}>
                            <td>{exp.description}</td>
                            <td>{exp.category}</td>
                            <td>${exp.amount}</td>
                            <td>{formatDate(exp.date)}</td>
                            <td>
                                <span className='px-2' style={{ cursor: 'pointer' }} onClick={() => { handleEdit(exp) }}> <FontAwesomeIcon className='text-info' icon={faPenToSquare} /> </span>
                                <span className='px-2' style={{ cursor: 'pointer' }} onClick={() => { handleDelete(exp._id) }}> <FontAwesomeIcon className='text-danger' icon={faTrash} /> </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <Alert alertBox={alertBox} setAlertBox={setAlertBox} />
        </div>
    );
}

export default ExpenseTracker;