import { useDispatch, useSelector } from "react-redux";
import BudgetUtilization from "../components/BudgetUtilization";
import ExpenseReport from "../components/ExpenseReport";
import IncomeReport from "../components/IncomeReport";
import SavingsReport from "../components/SavingsReport";
import { useEffect, useState } from "react";
import { fetchSavings } from "../features/savingsGloals";
import { fetchBudget } from "../features/budgetSlice";
import { fetchExpenses } from "../features/expenseSlice";
import { fetchIncomes } from "../features/incomeSlice";


function FinancialReport(props) {
    const dispatch = useDispatch();
    const { user } = useSelector((state) => state.auth);
    const { savings } = useSelector((state) => state.savings);
    const { incomes } = useSelector(state => state.income);
    const { budgets } = useSelector(state => state.budget);
    const { expenses } = useSelector(state => state.expense);

    useEffect(() => {
        if (user) {
            dispatch(fetchSavings(user._id));
            dispatch(fetchBudget(user._id));
            dispatch(fetchExpenses(user._id));
            dispatch(fetchIncomes(user._id));
        }
    }, [user, dispatch]);

    return (
        <div className="financial-dashboard">
            <IncomeReport data={incomes} />
            <ExpenseReport data={expenses} />
            <SavingsReport data={savings} />
            <BudgetUtilization budget={budgets} expenses={expenses} />
        </div>
    );
}

export default FinancialReport;