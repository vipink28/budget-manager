import React, { useState } from 'react';

function Notifications(props) {
    const [notifications, setNotifications] = useState([
        { message: 'Upcoming Bill Payment', type: 'Reminder' },
        { message: 'Budget Limit Reached', type: 'Alert' }
    ]);

    return (
        <div className="container mt-4">
            <h2>Notifications</h2>
            <ul className="list-group">
                {notifications.map((notification, index) => (
                    <li key={index} className="list-group-item">
                        {notification.message} - <span className="text-muted">{notification.type}</span>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default Notifications;