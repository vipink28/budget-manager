import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Alert from '../components/Alert';
import { formatDate } from '../helper';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrash } from '@fortawesome/free-solid-svg-icons';
import { addSavings, deleteSavings, fetchSavings, resetAddSavingsSuccess, updateSavings } from '../features/savingsGloals';

function SavingsGoal(props) {
    const dispatch = useDispatch();
    const { addSavingsSuccess, savings } = useSelector(state => state.savings);
    const { user } = useSelector(state => state.auth);
    const [alertBox, setAlertBox] = useState({
        show: false,
        alertType: 'success',
        alertMessage: ''
    });
    const [saving, setSaving] = useState({ goal: '', targetAmount: 0, currentAmount: 0, targetDate: Date() });
    const [editingSavings, setEditingSavings] = useState(null);

    const handleEdit = (saving) => {
        setEditingSavings(saving._id);
        setSaving({
            goal: saving.goal,
            targetAmount: saving.targetAmount,
            currentAmount: saving.currentAmount,
            targetDate: saving.targetDate
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (editingSavings) {
            dispatch(updateSavings({ id: editingSavings, data: saving }));
            setEditingSavings(null);
        } else {
            dispatch(addSavings(saving));
        }
        setSaving({ goal: '', targetAmount: 0, currentAmount: 0, targetDate: Date() });
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setSaving((prev) => ({
            ...prev,
            [name]: value,
            user: user
        }))
    }

    const handleDelete = (id) => {
        dispatch(deleteSavings(id));
    };

    useEffect(() => {
        if (addSavingsSuccess) {
            setAlertBox({ alertType: 'success', alertMessage: 'Savings Added Successfully', show: true });
            dispatch(fetchSavings(user._id));
            dispatch(resetAddSavingsSuccess());
        }
    }, [addSavingsSuccess, dispatch]);

    useEffect(() => {
        if (user) {
            dispatch(fetchSavings(user._id))
        }
    }, [user, dispatch])

    return (
        <div className="container mt-4">
            <h2>Savings Goals</h2>
            <form onSubmit={handleSubmit} className="mb-3">
                <div className="form-group">
                    <label>Goal Name</label>
                    <input type="text" className="form-control" name='goal' value={saving.goal} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Target Amount</label>
                    <input type="number" className="form-control" name='targetAmount' value={saving.targetAmount} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Current Amount</label>
                    <input type="number" className="form-control" name='currentAmount' value={saving.currentAmount} onChange={handleChange} />
                </div>

                <div className="form-group">
                    <label>Target Date</label>
                    <input type="date" className="form-control" name='date' value={saving.date} onChange={handleChange} />
                </div>

                <button type="submit" className="btn btn-primary">{editingSavings ? 'Update Savings' : 'Add Savings'}</button>
            </form>
            <table className="table">
                <thead>
                    <tr>
                        <th>Goal Name</th>
                        <th>Target Amount</th>
                        <th>Current Amount</th>
                    </tr>
                </thead>
                <tbody>
                    {savings.map((sav, index) => (
                        <tr key={index}>
                            <td>{sav.goal}</td>
                            <td>{sav.targetAmount}</td>
                            <td>${sav.currentAmount}</td>
                            <td>{formatDate(sav.targetDate)}</td>
                            <td>
                                <span className='px-2' style={{ cursor: 'pointer' }} onClick={() => { handleEdit(sav) }}> <FontAwesomeIcon className='text-info' icon={faPenToSquare} /> </span>
                                <span className='px-2' style={{ cursor: 'pointer' }} onClick={() => { handleDelete(sav._id) }}> <FontAwesomeIcon className='text-danger' icon={faTrash} /> </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <Alert alertBox={alertBox} setAlertBox={setAlertBox} />
        </div>
    );
}

export default SavingsGoal;

