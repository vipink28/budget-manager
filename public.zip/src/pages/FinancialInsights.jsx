import React from 'react';

function FinancialInsights(props) {
    // Placeholder insights - replace with dynamic data
    const insights = [
        "Your grocery spending has increased by 10% this month.",
        "You are on track to meet your savings goal for this quarter."
    ];

    return (
        <div className="container mt-4">
            <h2>Financial Insights</h2>
            <ul className="list-group">
                {insights.map((insight, index) => (
                    <li key={index} className="list-group-item">{insight}</li>
                ))}
            </ul>
        </div>
    );
}

export default FinancialInsights;