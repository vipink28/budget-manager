import React from 'react';

function Dashboard(props) {
    return (
        <div className="container mt-4">
            <h1>Dashboard</h1>
            {/* Add Overview and Graphs Here */}
        </div>
    );
}

export default Dashboard;