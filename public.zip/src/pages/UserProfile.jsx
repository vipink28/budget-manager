import React, { useState } from 'react';

function UserProfile(props) {
    const [user, setUser] = useState({ username: '', email: '' });

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle Profile Update Logic
    };

    return (
        <div className="container mt-4">
            <h2>User Profile</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Username</label>
                    <input type="text" className="form-control" value={user.username} onChange={(e) => setUser({ ...user, username: e.target.value })} />
                </div>
                <div className="form-group">
                    <label>Email</label>
                    <input type="email" className="form-control" value={user.email} onChange={(e) => setUser({ ...user, email: e.target.value })} />
                </div>
                {/* Add more fields as needed */}
                <button type="submit" className="btn btn-primary">Update Profile</button>
            </form>
        </div>
    );
}

export default UserProfile;