import { faChartLine, faCoins, faFileInvoiceDollar, faGauge, faHandHoldingDollar, faHome, faPiggyBank, faSackDollar } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';

function AdminLayout(props) {
    const navigate = useNavigate();
    const logout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('userId');
        navigate('/login');
    }
    return (
        <>
            <div className='d-flex h-100'>
                <div className="d-flex flex-column h-100 flex-shrink-0 p-3 text-bg-dark" style={{ width: 280 }}>
                    <NavLink to="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                        <FontAwesomeIcon className='bi pe-none me-2' icon={faHome} />
                        <span className="fs-4">Sidebar</span>
                    </NavLink>
                    <hr />
                    <ul className="nav nav-pills flex-column mb-auto">
                        <li className="nav-item">

                            <NavLink to="/admin/dashboard" className="nav-link text-white" aria-current="page">
                                <FontAwesomeIcon className='bi pe-none me-2' icon={faGauge} />
                                Dashboard
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/admin/income" className="nav-link text-white">
                                <FontAwesomeIcon className='bi pe-none me-2' icon={faHandHoldingDollar} />
                                Income
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/admin/expense" className="nav-link text-white">
                                <FontAwesomeIcon className='bi pe-none me-2' icon={faFileInvoiceDollar} />
                                Expense
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/admin/budget-plan" className="nav-link text-white">
                                <FontAwesomeIcon className='bi pe-none me-2' icon={faSackDollar} />
                                Budget Plan
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/admin/financial-insights" className="nav-link text-white">
                                <FontAwesomeIcon className='bi pe-none me-2' icon={faCoins} />
                                Financial Insights
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/admin/financial-reports" className="nav-link text-white">
                                <FontAwesomeIcon className='bi pe-none me-2' icon={faChartLine} />
                                Financial Reports
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to="/admin/savings-goal" className="nav-link text-white">
                                <FontAwesomeIcon className='bi pe-none me-2' icon={faPiggyBank} />
                                Savings Goal
                            </NavLink>
                        </li>
                    </ul>

                </div>
                <div className='w-100'>
                    <div className='container-fluid d-flex justify-content-end py-3 bg-light'>
                        <div className="dropdown">
                            <NavLink to="#" className="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="https://github.com/mdo.png" alt="" width="32" height="32" className="rounded-circle me-2" />
                                <strong>mdo</strong>
                            </NavLink>
                            <ul className="dropdown-menu dropdown-menu-dark text-small shadow">
                                <li style={{ cursor: 'pointer' }} onClick={logout}><span className="dropdown-item">Sign out</span></li>
                            </ul>
                        </div>
                    </div>
                    <div className='container'>
                        <Outlet />
                    </div>
                </div>
            </div>
        </>
    );
}

export default AdminLayout;