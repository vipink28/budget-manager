
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Alert from '../components/Alert';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrash } from '@fortawesome/free-solid-svg-icons';
import { addBudget, deleteBudget, fetchBudget, resetAddBudgetSuccess, updateBudget } from '../features/budgetSlice';

function BudgetPlan(props) {
    const dispatch = useDispatch();
    const { addBudgetSuccess, budgets } = useSelector(state => state.budget);
    const { user } = useSelector(state => state.auth);
    const [alertBox, setAlertBox] = useState({
        show: false,
        alertType: 'success',
        alertMessage: ''
    });
    const [budget, setBudget] = useState({ limit: 0, limit: '' });
    const [editingBudget, setEditingBudget] = useState(null);

    const handleEdit = (budget) => {
        setEditingBudget(budget._id);
        setBudget({
            limit: budget.limit,
            category: budget.category
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (editingBudget) {
            dispatch(updateBudget({ id: editingBudget, data: budget }));
            setEditingBudget(null);
        } else {
            dispatch(addBudget(budget));
        }
        setBudget({ limit: 0, category: '' });
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setBudget((prev) => ({
            ...prev,
            [name]: value,
            user: user
        }))
    }

    const handleDelete = (id) => {
        dispatch(deleteBudget(id));
    };

    useEffect(() => {
        if (addBudgetSuccess) {
            setAlertBox({ alertType: 'success', alertMessage: 'Budget Added Successfully', show: true });
            dispatch(fetchBudget(user._id));
            dispatch(resetAddBudgetSuccess());
        }
    }, [addBudgetSuccess, dispatch]);

    useEffect(() => {
        if (user) {
            dispatch(fetchBudget(user._id))
        }
    }, [user, dispatch])
    return (
        <div className="container mt-4">
            <h2>Budget Plan</h2>
            <form onSubmit={handleSubmit} className="mb-3">
                <div className="form-group">
                    <label>Category</label>
                    <input type="text" className="form-control" name='category' value={budget.category} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Limit</label>
                    <input type="number" className="form-control" name='limit' value={budget.limit} onChange={handleChange} />
                </div>
                <button type="submit" className="btn btn-primary">{editingBudget ? 'Update Budget' : 'Add Budget'}</button>
            </form>
            <table className="table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Limit</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {budgets.map((bud, index) => (
                        <tr key={index}>
                            <td>{bud.category}</td>
                            <td>{bud.limit}</td>
                            <td>
                                <span className='px-2' style={{ cursor: 'pointer' }} onClick={() => { handleEdit(bud) }}> <FontAwesomeIcon className='text-info' icon={faPenToSquare} /> </span>
                                <span className='px-2' style={{ cursor: 'pointer' }} onClick={() => { handleDelete(bud._id) }}> <FontAwesomeIcon className='text-danger' icon={faTrash} /> </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default BudgetPlan;