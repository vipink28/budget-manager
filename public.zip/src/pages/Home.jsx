import React from 'react';
import budgetImg from '../assets/budgetimg.jpg';
import { Outlet } from 'react-router-dom';

function Home(props) {
    return (
        <div className='vh-100'>
            <div className='container h-100 d-flex align-items-center justify-content-center'>
                <div className="card" style={{ maxWidth: 800 }}>
                    <div className="row g-0">
                        <div className="col-md-5">
                            <img src={budgetImg} className="img-fluid object-fit-cover h-100 rounded-start" alt="..." />
                        </div>
                        <div className="col-md-7">
                            <div className="card-body">
                                <Outlet />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Home;