
import React, { useEffect, useState } from 'react';
import { addIncome, deleteIncome, fetchIncomes, resetAddIncomeSuccess, updateIncome } from '../features/incomeSlice';
import { useDispatch, useSelector } from 'react-redux';
import Alert from '../components/Alert';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrash } from '@fortawesome/free-solid-svg-icons';

function IncomeTracker(props) {
    const dispatch = useDispatch();
    const { addIncomeSuccess, incomes } = useSelector(state => state.income);
    const { user } = useSelector(state => state.auth);
    const [alertBox, setAlertBox] = useState({
        show: false,
        alertType: 'success',
        alertMessage: ''
    });
    const [income, setIncome] = useState({ source: '', amount: 0, category: '' });
    const [editingIncome, setEditingIncome] = useState(null);

    const handleEdit = (income) => {
        setEditingIncome(income._id);
        setIncome({
            source: income.source,
            amount: income.amount,
            category: income.category
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (editingIncome) {
            dispatch(updateIncome({ id: editingIncome, data: income }));
            setEditingIncome(null);
        } else {
            dispatch(addIncome(income));
        }
        setIncome({ source: '', amount: 0, category: '' });
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setIncome((prev) => ({
            ...prev,
            [name]: value,
            user: user
        }))
    }

    const handleDelete = (id) => {
        dispatch(deleteIncome(id));
    };

    useEffect(() => {
        if (addIncomeSuccess) {
            setAlertBox({ alertType: 'success', alertMessage: 'Income Added Successfully', show: true });
            dispatch(fetchIncomes(user._id));
            dispatch(resetAddIncomeSuccess());
        }
    }, [addIncomeSuccess, dispatch]);

    useEffect(() => {
        if (user) {
            dispatch(fetchIncomes(user._id))
        }
    }, [user, dispatch])

    return (
        <div className="container mt-4">
            <h2>Income Tracker</h2>
            <form onSubmit={handleSubmit} className="mb-3">
                <div className="mb-3">
                    <label className='form-label'>Income Source</label>
                    <input type="text" className="form-control" name='source' value={income.source} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label className='form-label'>Amount</label>
                    <input type="number" className="form-control" name='amount' value={income.amount} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label className='form-label'>Category</label>
                    <select
                        className="form-control"
                        value={income.category}
                        onChange={handleChange}
                        name='category'
                    >
                        <option value="">Select a Category</option>
                        <option value="Salary">Salary</option>
                        <option value="Investment">Investment</option>
                        <option value="Freelance">Freelance</option>
                    </select>
                </div>
                <button type="submit" className="btn btn-primary">{editingIncome ? 'Update Income' : 'Add Income'}</button>
            </form>
            <table className="table">
                <thead>
                    <tr>
                        <th>Source</th>
                        <th>Category</th>
                        <th>Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {incomes.map((inc, index) => (
                        <tr key={index}>
                            <td>{inc.source}</td>
                            <td>{inc.category}</td>
                            <td>${inc.amount}</td>
                            <td>
                                <span className='px-2' style={{ cursor: 'pointer' }} onClick={() => { handleEdit(inc) }}> <FontAwesomeIcon className='text-info' icon={faPenToSquare} /> </span>
                                <span className='px-2' style={{ cursor: 'pointer' }} onClick={() => { handleDelete(inc._id) }}> <FontAwesomeIcon className='text-danger' icon={faTrash} /> </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <Alert alertBox={alertBox} setAlertBox={setAlertBox} />
        </div>
    );
}

export default IncomeTracker;