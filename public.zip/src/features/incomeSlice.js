import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from '../helper/axios'; // Import your axios instance

// Async thunk for fetching incomes
export const fetchIncomes = createAsyncThunk('income/fetchIncomes', async (id) => {
    const response = await axios.get(`/income?userId=${id}`);
    return response.data;
});

// Async thunk for adding a new income
export const addIncome = createAsyncThunk('income/addIncome', async (incomeData) => {
    const response = await axios.post('/income', incomeData);
    return response.data;
});

// Async thunk for updating an income
export const updateIncome = createAsyncThunk('income/updateIncome', async ({ id, data }) => {
    const response = await axios.put(`/income/${id}`, data);
    return response.data;
});

// Async thunk for deleting an income
export const deleteIncome = createAsyncThunk('income/deleteIncome', async (id) => {
    await axios.delete(`/income/${id}`);
    return id;
});

const incomeSlice = createSlice({
    name: 'income',
    initialState: {
        incomes: [],
        loading: false,
        error: null,
        addIncomeSuccess: false,
        updateIncomeSuccess: false,
        deleteIncomeSuccess: false
    },
    reducers: {
        resetAddIncomeSuccess: (state) => {
            state.addIncomeSuccess = false;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchIncomes.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(fetchIncomes.fulfilled, (state, action) => {
                state.loading = false;
                state.incomes = action.payload;
            })
            .addCase(fetchIncomes.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(addIncome.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(addIncome.fulfilled, (state, action) => {
                state.loading = false;
                state.incomes.push(action.payload);
                state.addIncomeSuccess = true;
            })
            .addCase(addIncome.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(updateIncome.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(updateIncome.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.incomes.findIndex(income => income._id === action.payload._id);
                state.incomes[index] = action.payload;
                state.updateIncomeSuccess = true;
            })
            .addCase(updateIncome.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(deleteIncome.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(deleteIncome.fulfilled, (state, action) => {
                state.loading = false;
                state.incomes = state.incomes.filter(income => income._id !== action.payload);
                state.deleteIncomeSuccess = true;
            })
            .addCase(deleteIncome.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
    }
});

export const { resetAddIncomeSuccess } = incomeSlice.actions;

export default incomeSlice.reducer;