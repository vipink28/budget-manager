import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from '../helper/axios'; // Import your axios instance

// Async thunk for fetching incomes
export const fetchExpenses = createAsyncThunk('expenses/fetchExpenses', async (id) => {
    const response = await axios.get(`/expenses?userId=${id}`);
    return response.data;
});

// Async thunk for adding a new income
export const addExpense = createAsyncThunk('expenses/addExpense', async (incomeData) => {
    const response = await axios.post('/expenses', incomeData);
    return response.data;
});

// Async thunk for updating an income
export const updateExpense = createAsyncThunk('expenses/updateExpense', async ({ id, data }) => {
    const response = await axios.put(`/expenses/${id}`, data);
    return response.data;
});

// Async thunk for deleting an income
export const deleteExpense = createAsyncThunk('expenses/deleteExpense', async (id) => {
    await axios.delete(`/expenses/${id}`);
    return id;
});

const expenseSlice = createSlice({
    name: 'expenses',
    initialState: {
        expenses: [],
        loading: false,
        error: null,
        addExpenseSuccess: false,
        updateExpenseSuccess: false,
        deleteExpenseSuccess: false
    },
    reducers: {
        resetAddExpenseSuccess: (state) => {
            state.addExpenseSuccess = false;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchExpenses.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(fetchExpenses.fulfilled, (state, action) => {
                state.loading = false;
                state.expenses = action.payload;
            })
            .addCase(fetchExpenses.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(addExpense.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(addExpense.fulfilled, (state, action) => {
                state.loading = false;
                state.expenses.push(action.payload);
                state.addExpenseSuccess = true;
            })
            .addCase(addExpense.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(updateExpense.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(updateExpense.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.expenses.findIndex(expense => expense._id === action.payload._id);
                state.expenses[index] = action.payload;
                state.updateExpenseSuccess = true;
            })
            .addCase(updateExpense.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(deleteExpense.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(deleteExpense.fulfilled, (state, action) => {
                state.loading = false;
                state.incomes = state.expenses.filter(expense => expense._id !== action.payload);
                state.deleteExpenseSuccess = true;
            })
            .addCase(deleteExpense.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
    }
});

export const { resetAddExpenseSuccess } = expenseSlice.actions;

export default expenseSlice.reducer;