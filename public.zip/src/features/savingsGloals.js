import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from '../helper/axios'; // Import your axios instance

// Async thunk for fetching incomes
export const fetchSavings = createAsyncThunk('savings/fetchSavings', async (id) => {
    console.log(id);
    const response = await axios.get(`/savings?userId=${id}`);
    console.log(response);
    return response.data;
});

// Async thunk for adding a new income
export const addSavings = createAsyncThunk('savings/addSavings', async (savingsData) => {
    const response = await axios.post('/savings', savingsData);
    return response.data;
});

// Async thunk for updating an income
export const updateSavings = createAsyncThunk('savings/updateSavings', async ({ id, data }) => {
    const response = await axios.put(`/savings/${id}`, data);
    return response.data;
});

// Async thunk for deleting an income
export const deleteSavings = createAsyncThunk('savings/deleteSavings', async (id) => {
    await axios.delete(`/savings/${id}`);
    return id;
});

const savingsSlice = createSlice({
    name: 'savings',
    initialState: {
        savings: [],
        loading: false,
        error: null,
        addSavingsSuccess: false,
        updateSavingsSuccess: false,
        deleteSavingsSuccess: false
    },
    reducers: {
        resetAddSavingsSuccess: (state) => {
            state.addSavingsSuccess = false;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchSavings.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(fetchSavings.fulfilled, (state, action) => {
                state.loading = false;
                state.savings = action.payload;
            })
            .addCase(fetchSavings.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(addSavings.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(addSavings.fulfilled, (state, action) => {
                state.loading = false;
                state.savings.push(action.payload);
                state.addSavingsSuccess = true;
            })
            .addCase(addSavings.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(updateSavings.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(updateSavings.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.savings.findIndex(saving => saving._id === action.payload._id);
                state.savings[index] = action.payload;
                state.updateSavingsSuccess = true;
            })
            .addCase(updateSavings.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(deleteSavings.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(deleteSavings.fulfilled, (state, action) => {
                state.loading = false;
                state.savings = state.savings.filter(saving => saving._id !== action.payload);
                state.deleteSavingsSuccess = true;
            })
            .addCase(deleteSavings.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
    }
});

export const { resetAddSavingsSuccess } = savingsSlice.actions;

export default savingsSlice.reducer;