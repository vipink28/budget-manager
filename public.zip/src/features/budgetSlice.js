import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from '../helper/axios'; // Import your axios instance

// Async thunk for fetching budgets
export const fetchBudget = createAsyncThunk('budget/fetchBudget', async (id) => {
    const response = await axios.get(`/budget?userId=${id}`);
    return response.data;
});

// Async thunk for adding a new budget
export const addBudget = createAsyncThunk('budget/addBudget', async (budgetData) => {
    const response = await axios.post('/budget', budgetData);
    return response.data;
});

// Async thunk for updating an budget
export const updateBudget = createAsyncThunk('budget/updateBudget', async ({ id, data }) => {
    const response = await axios.put(`/budget/${id}`, data);
    return response.data;
});

// Async thunk for deleting an budget
export const deleteBudget = createAsyncThunk('budget/deleteBudget', async (id) => {
    await axios.delete(`/budget/${id}`);
    return id;
});

const budgetSlice = createSlice({
    name: 'budget',
    initialState: {
        budgets: [],
        loading: false,
        error: null,
        addBudgetSuccess: false,
        updateBudgetSuccess: false,
        deleteBudgetSuccess: false
    },
    reducers: {
        resetAddBudgetSuccess: (state) => {
            state.addBudgetSuccess = false;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchBudget.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(fetchBudget.fulfilled, (state, action) => {
                state.loading = false;
                state.budgets = action.payload;
            })
            .addCase(fetchBudget.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(addBudget.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(addBudget.fulfilled, (state, action) => {
                state.loading = false;
                state.budgets.push(action.payload);
                state.addBudgetSuccess = true;
            })
            .addCase(addBudget.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(updateBudget.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(updateBudget.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.budgets.findIndex(budget => budget._id === action.payload._id);
                state.budgets[index] = action.payload;
                state.updateBudgetSuccess = true;
            })
            .addCase(updateBudget.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
            .addCase(deleteBudget.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(deleteBudget.fulfilled, (state, action) => {
                state.loading = false;
                state.budgets = state.budgets.filter(budget => budget._id !== action.payload);
                state.deleteBudgetSuccess = true;
            })
            .addCase(deleteBudget.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error;
            })
    }
});

export const { resetAddBudgetSuccess } = budgetSlice.actions;

export default budgetSlice.reducer;