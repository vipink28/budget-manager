import React from 'react';
import "chart.js/auto";
import { Line } from 'react-chartjs-2';


function IncomeReport({ data }) {
    let chartData;

    // Check if data is not empty
    if (data && data.length > 0) {
        // Extracting dates and amounts
        const dates = data.map(income => new Date(income.date).toLocaleDateString());
        const amounts = data.map(income => income.amount);

        chartData = {
            labels: dates,
            datasets: [
                {
                    label: 'Income over Time',
                    data: amounts,
                    fill: false,
                    backgroundColor: 'rgb(75, 192, 192)',
                    borderColor: 'rgba(75, 192, 192, 0.2)',
                },
            ],
        };
    } else {
        // Default empty chart data
        chartData = {
            labels: [],
            datasets: [
                {
                    label: 'Income over Time',
                    data: [],
                    fill: false,
                    backgroundColor: 'rgb(75, 192, 192)',
                    borderColor: 'rgba(75, 192, 192, 0.2)',
                },
            ],
        };
    }


    return (
        <div className='py-3'>
            <h2>Income Overview</h2>
            <Line data={chartData} />
        </div>
    );
}

export default IncomeReport;