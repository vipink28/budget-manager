import React from 'react';

function ExpenseReport(props) {
    return (
        <div>

        </div>
    );
}

export default ExpenseReport;