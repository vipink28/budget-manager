import React from 'react';

function BudgetUtilization(props) {
    return (
        <div>

        </div>
    );
}

export default BudgetUtilization;