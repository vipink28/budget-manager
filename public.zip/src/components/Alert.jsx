import React, { useEffect } from 'react';

function Alert(props) {
    const { alertBox, setAlertBox } = props;
    const { show, alertType, alertMessage } = alertBox;
    useEffect(() => {
        if (show) {
            setTimeout(() => {
                setAlertBox(false);
            }, 3000);
        }
    }, [show])
    return (
        <>
            {
                show ?
                    <div className={`alert position-fixed alert-${alertType}`} style={{ top: 0, left: '50%', transform: 'translateX(-50%)' }} role="alert">
                        {alertMessage}
                    </div> : ""
            }
        </>
    );
}

export default Alert;